# script-2420-fall21
fuzzy finder script for 2420 exam
